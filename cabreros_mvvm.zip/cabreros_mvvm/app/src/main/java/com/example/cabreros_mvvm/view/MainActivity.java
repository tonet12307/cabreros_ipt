package com.example.cabreros_mvvm.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cabreros_mvvm.R;
import com.example.cabreros_mvvm.adapter.FoodAdapter;
import com.example.cabreros_mvvm.viewmodel.FoodViewModel;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FoodViewModel foodViewModel =
                new ViewModelProvider(this).get(FoodViewModel.class);

        FoodAdapter adapter = new FoodAdapter(foodViewModel.getFoodList());
        recyclerView.setAdapter( adapter);
    }
}
