package com.example.cabreros_mvvm.model;

public class Food {

    private final String name;
    private final String description;
    private final String price;
    private final int imageRes;

    public Food(String name, String description, String price, int imageRes) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageRes = imageRes;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getPrice() {
        return price;
    }

    public int getImageRes() {
        return imageRes;
    }
}
