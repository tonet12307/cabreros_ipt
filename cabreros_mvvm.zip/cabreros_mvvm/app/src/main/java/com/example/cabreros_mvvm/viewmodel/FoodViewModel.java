package com.example.cabreros_mvvm.viewmodel;

import androidx.lifecycle.ViewModel;

import com.example.cabreros_mvvm.R;
import com.example.cabreros_mvvm.model.Food;

import java.util.ArrayList;
import java.util.List;

public class FoodViewModel extends ViewModel {

    public List<Food> getFoodList() {

        List<Food> foodList = new ArrayList<>();

        foodList.add(new Food(
                "Milk Tea",
                "Creamy milk tea with chewy pearls",
                "₱120.00",
                R.drawable.milktea
        ));

        foodList.add(new Food(
                "Nachos",
                "Crunchy nachos with cheese sauce",
                "₱150.00",
                R.drawable.nachos
        ));

        foodList.add(new Food(
                "Burger",
                "Juicy beef burger with fresh veggies",
                "₱180.00",
                R.drawable.burger
        ));

        return foodList;
    }
}
